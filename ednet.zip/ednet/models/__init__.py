from .yolo import YOLO, EDNet

__all__ = "YOLO", "EDNet"